#include <stdlib.h>
#include <stdio.h>
#include <math.h> // pow
#include <stdbool.h> 
/* Ligne de commande pour compiler :
 * gcc -std=c99 -Wall -Wextra -pedantic -ggdb -Wno-abi -o executable exercice3.c -lm
 */

/* Prototype des fonctions qui vont être utilisées par un programme externe 
 * NOTE : il n'est pas obligatoire de déclarer somme_diviseurs, dont l'utilisation 
 * sera limitée à exercice3_implementation.c 
 * Une autre fonction somme_diviseurs_sqrt existe dans ce fichier, et des explications 
 * supplémentaires sur son fonctionnement sont données en commentaire */
int somme_diviseurs(int);
bool parfait(int);
bool parfait_optimise(int);
bool munchhausen(int);


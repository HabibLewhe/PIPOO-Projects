#include "exercice3_header.h"

/* Pour la phase de compilation, il faut d'abord :
 * - compiler l'implémentation des fonctions : gcc -o exercice3_implementation.o -c exercice3_implementation.c
 * - compiler la fonction principale : gcc -o main_exercice3.o -c main_exercice3.c
 * - lier les fichiers .o avec la librarie math.h : gcc -o exercice3 exercice3_implementation.o main_exercice3.o -lm
 */

int main() {
    int p = 8128;
    somme_diviseurs_strict(p);
    int non_p = 921;
    printf("%d parfait ? %d\n", p, parfait(p));
    printf("%d parfait ? %d\n", non_p, parfait(non_p));

    printf("%d parfait (avec optimisation) ? %d\n", p, parfait_optimise(p));
    printf("%d parfait (avec optimisation) ? %d\n", non_p, parfait_optimise(non_p));

    int m = 3435;
    int non_m = 45904;
    printf("%d nombre de Munchhausen ? %d\n", m, munchhausen(m));
    printf("%d nombre de Munchhausen ? %d\n", non_m, munchhausen(non_m));

    return EXIT_SUCCESS;
}


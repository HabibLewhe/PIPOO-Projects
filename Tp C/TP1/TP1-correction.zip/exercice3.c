#include <stdlib.h>
#include <stdio.h>
#include <math.h> // pow
#include <stdbool.h> 
/* Ligne de commande pour compiler :
 * gcc -std=c99 -Wall -Wextra -pedantic -ggdb -Wno-abi -o executable exercice3.c -lm
 */

/* Prototype des fonctions */
int somme_diviseurs(int);
int somme_diviseurs_sqrt(int);
bool parfait(int);
bool parfait_optimise(int);
bool munchhausen(int);

int main() {
    int p = 8128;
    int non_p = 921;
    printf("%d parfait ? %d\n", p, parfait(p));
    printf("%d parfait ? %d\n", non_p, parfait(non_p));

    printf("%d parfait (avec optimisation) ? %d\n", p, parfait_optimise(p));
    printf("%d parfait (avec optimisation) ? %d\n", non_p, parfait_optimise(non_p));

    int m = 3435;
    int non_m = 45904;
    printf("%d nombre de Munchhausen ? %d\n", m, munchhausen(m));
    printf("%d nombre de Munchhausen ? %d\n", non_m, munchhausen(non_m));

    return EXIT_SUCCESS;
}

int somme_diviseurs(int n) {
    int somme = 1;
    for(int i = 2; i < n; ++i) {
        if(n % i == 0) {
            /* i est un diviseur de n */
            somme = somme + i;
        }
    }
    return somme;
}

bool parfait(int n) {
    /* On compare la somme des diviseurs et le nombre lui-même */
    return (somme_diviseurs(n) == n);
}

int somme_diviseurs_sqrt(int n) {
    int somme = 1;
    for(int i = 2; i < (int)sqrt(n)+1; ++i) {
        if(n % i == 0) {
            /* i est un diviseur de n */
            somme = somme + i;
            /* Pour calculer la somme des diviseurs de 64, la boucle va s'arrêter à i = 8 : 
             * il faut donc penser à rajouter les diviseurs *strictement* supérieurs
             * par exemple 64 = 2 * 32(=64/2), 64=4*16(=16/4) et ne pas compter 8 deux fois
             */
            int q = n / i;
            if(q > i)
                somme+=q;
        }
    }
    return somme;
}

bool parfait_optimise(int n) {
    /* On compare la somme des diviseurs et le nombre lui-même */
    return (somme_diviseurs_sqrt(n) == n);
}

bool munchhausen(int n) {
    int somme = 0;
    int copie = n;
    /* On parcourt le nombre unité par unité, en divisant par 10 
     * à chaque étape pour se "décaler vers la gauche"
     */
    while(n != 0) {
        int unite = n % 10;
        somme += pow(unite,unite);
        /* n/10 retourne un réel, converti en int
         * NOTE : n étant lui-même un int, cette conversion est implicitement 
         * réalisée par le langage C et l'instruction n = n / 10 est valide
         */
        n = (int)n / 10;
    }

    return (somme == copie);
}

#ifndef PASCAL_H
#define PASCAL_H
#include "fonctions.h"

void pascal(int);

#endif

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

bool egalite( void*, void*, bool(*est_egal)(void*, void*));

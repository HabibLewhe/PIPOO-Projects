#include <stdlib.h>
#include <stdio.h>

typedef struct une_struct* structure; 

structure initialiser_structure(char *, int); 
void afficher_structure(structure s);

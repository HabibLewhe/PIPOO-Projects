#include <stdlib.h>
#include <stdio.h>

struct une_struct; 

struct une_struct* initialiser_structure(char*, int); 
void afficher_structure(struct une_struct *s);
